#include "linkedlist.h"
#include <stdlib.h>
#include <stdio.h>

/// <summary>
/// Function to insert a given node at the front of the linked list
/// </summary>
/// <param name="headRef">The list to add to</param>
/// <param name="newData">The node to add</param>
void Push(Node** headRef, int newData) {
	Node* newNode = malloc(sizeof(Node));
	if (newNode == NULL) {
		printf("\nError: Memory allocation failed at Push(Node**, int)");
		return;
	}

	newNode->data = newData;
	newNode->next = *headRef;

	*headRef = newNode;
}

/// <summary>
/// Function to remove a node from the front of a list and get its data
/// </summary>
/// <param name="headRef">The list to remove a node from</param>
/// <returns>The data of the node removed</returns>
int Pop(Node** headRef) {
	if (*headRef == NULL) {
		printf("\nError: Node list is empty at Pop(Node** headRef)");
		return -34403;
	}

	Node* temp = *headRef;
	int data = (temp->data);
                         
	*headRef = temp->next;

	free(temp);
	temp = NULL;
	return data;
}

/// <summary>
/// Function to count the number of occurences of a given integer in the list
/// </summary>
/// <param name="head">The list to serach in</param>
/// <param name="searchFor">The integer to count the occurences of</param>
/// <returns>The number of times the given integer was seen in the list</returns>
int Count(Node* head, int searchFor) { 
	int count = 0;
	while (head != NULL) {
		if (head->data == searchFor) {
			count++;
		}

		head = head->next;
	}

	return count;
}

/// <summary>
/// Function to get the data of a node at a given index
/// </summary>
/// <param name="head">The list to search through</param>
/// <param name="index">The index of the node to get data from</param>
/// <returns>The data of the node at the given index</returns>
int GetNth(Node** head, int index) {
	if (index < 0) {
		printf("\nError: Index out of bounds < at GetNth(Node**, int)");
		return -34403;
	}
	Node* track = *head;

	int count = 0;
	for (int i = 0; i < index && track != NULL; i++) {
		track = track->next;
	}

	if (track == NULL) {
		printf("\nError: Index out of bounds > at GetNth(Node**, int)");
		return -34403;
	}

	return track->data;
}

/// <summary>
/// Function to delete a given list and free the memory
/// </summary>
/// <param name="head">The list to delete and free</param>
void DeleteList(Node** head) {
	Node* temp = NULL;
	while (*head != NULL) {
		temp = *head;
		*head = temp->next;

		free(temp);
		temp = NULL;
	}
}

/// <summary>
/// Function to insert a node at a given index into a list
/// </summary>
/// <param name="head">The list to insert the node into</param>
/// <param name="index">The index at which to insert the node</param>
/// <param name="data">The data of the new node to be inserted</param>
void InsertNth(Node** head, int index, int data) {
	if (index < 0) {
		printf("\nError: Index out of bounds < at InsertNth(Node**, int, int)");
		return;
	}
	if (index == 0) {
		Push(head, data);
		return;
	}

	Node* track = *head;

	for (int i = 0; i < index - 1 && track != NULL; i++) {
		track = track->next;
	}

	if (track == NULL) {
		printf("\nError: Index out of bounds > at InsertNth(Node**, int, int)");
		return;
	}

	Node* newNode = malloc(sizeof(Node));
	if (newNode == NULL) {
		printf("\nError: Memory allocation failed at InserntNth(Node**, int, int)");
		return;
	}
	newNode->data = data;

	newNode->next = track->next;
	track->next = newNode;
}

/// <summary>
/// Function to move the head node of a list to the head of a different list
/// </summary>
/// <param name="destRef">The list where the node will be added to</param>
/// <param name="sourceRef">The list where the node is removed from</param>
void MoveNode(Node** destRef, Node** sourceRef) {
	if (*sourceRef == NULL) {
		printf("\nError: sourceRef is empty at MoveNode(Node**, Node**)");
		return;
	}

	Node* temp = *sourceRef;
	*sourceRef = temp->next;

	temp->next = *destRef;
	*destRef = temp;
}

/// <summary>
/// Function to reverse a list using recursion
/// </summary>
/// <param name="headRef">The list to reverse</param>
void RecursiveReverse(Node** headRef) {
	if (*headRef == NULL || (*headRef)->next == NULL) {
		return;
	}

	Node* newHead = (*headRef)->next;
	RecursiveReverse(&newHead);

	(*headRef)->next->next = *headRef;
	(*headRef)->next = NULL;

	*headRef = newHead;
}