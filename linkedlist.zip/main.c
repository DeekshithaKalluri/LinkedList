#include "linkedlist.h"
#include <stdlib.h>
#include <stdio.h>

void PrintList(Node* head);
void StartScreen();
void ClearInput();

/// <summary>
/// The main function for the program. This handles the execution using the helper
/// functions created in main.c and linkedlist.c to allow a user test the functionality
/// of the program and provides a visual of the linked list. It also handles incorrect
/// user input
/// </summary>
/// <returns>0</returns>
int main() {
	Node* list = NULL;
	Node* destLis = NULL;
	int number;
	int data;
	int index;
	int result;
	int print;

	do {
		StartScreen();
		print = scanf("%d", &number);
		if (print != 1 || print == EOF) {
			printf("\nError: Invalid input, please enter a valid integer.\n\n");
			ClearInput();
			continue;
		}

		if (number < 0 || number > 9) {
			printf("\nError in input please try again\n\n");
			continue;
		}

		switch (number) {
		case 1:
			printf("Enter data to add: ");
			print = scanf("%d", &data);
			if (print != 1) {
				printf("\nError: Invalid input, please enter a valid integer.\n\n");
				ClearInput();
				continue;
			}

			Push(&list, data);
			break;
		case 2:
			result = Pop(&list);
			printf("\nData of head node: %d", result);
			break;
		case 3:
			printf("Enter integer to count: ");
			print = scanf("%d", &data);
			if (print != 1) {
				printf("\nError: Invalid input, please enter a valid integer.\n\n");
				ClearInput();
				continue;
			}

			result = Count(list, data);
			printf("\nCount of given integer: %d", result);
			break;
		case 4:
			printf("Enter index of node to get data from(starts at 0): ");
			print = scanf("%d", &index);
			if (print != 1) {
				printf("\nError: Invalid input, please enter a valid integer.\n\n");
				ClearInput();
				continue;
			}

			result = GetNth(&list, index);
			printf("\nData of node %d: %d", index, result);
			break;
		case 5:
			DeleteList(&list);
			DeleteList(&destLis);
			printf("\nCurrent list and destination list deleted");
			printf("\nDestination List:\n");
			PrintList(destLis);
			break;
		case 6:
			printf("Enter index to insert new node: ");
			print = scanf("%d", &index);
			if (print != 1) {
				printf("\nError: Invalid input, please enter a valid integer.\n\n");
				ClearInput();
				continue;
			}

			printf("Enter data of new node: ");
			print = scanf("%d", &data);
			if (print != 1) {
				printf("\nError: Invalid input, please enter a valid integer.\n\n");
				ClearInput();
				continue;
			}

			InsertNth(&list, index, data);
			break;
		case 7:
			MoveNode(&destLis, &list);
			printf("\nDestination List:\n");
			PrintList(destLis);
			break;
		case 8:
			RecursiveReverse(&list);
			printf("\nList reversed");
			break;
		case 9:
			DeleteList(&list);
			DeleteList(&destLis);
			for (int i = 9; i > 0; i--) {
				Push(&list, i);
			}
			break;
		}

		printf("\nNew/Current list:\n");
		PrintList(list);
	} while (number != 0);

	DeleteList(&list);
	DeleteList(&destLis);
	return 0;
}

/// <summary>
/// Function used to provide a visual of the linked list given
/// </summary>
/// <param name="head">The list to print out</param>
void PrintList(Node* head) {
	while (head != NULL) {
		printf("%d -> ", head->data);
		head = head->next;
	}

	printf("NULL\n\n");
}

/// <summary>
/// Function to print the start screen describing the possible test to run
/// </summary>
void StartScreen() {
	printf("1 : Push a node to head of list\n");
	printf("2 : Remove the head node and return its data\n");
	printf("3 : Count the occurrences of a given integer in the list\n");
	printf("4 : Get the data of a node at a given index\n");
	printf("5 : Delete all the nodes and free memory\n");
	printf("6 : Insert a node at a given index\n");
	printf("7 : Move the from node from source to destination list\n");
	printf("8 : Recursively reverse the list\n");
	printf("9 : Add premade list 1-9 ascending\n");
	printf("0 : Stop program\n");
	printf("Enter a number: ");
}

/// <summary>
/// Function to clear the input buffer to help handle incorrect input
/// </summary>
void ClearInput() {
	while (getchar() != '\n');
}