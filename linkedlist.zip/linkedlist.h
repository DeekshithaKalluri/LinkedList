//#ifndef LINKEDLIST_H
#define LINKEDLIST_H

/// <summary>
/// The structure of the nodes that will be used in a linked list
/// </summary>
typedef struct node {
    int data;
    struct node* next;
} Node;

void Push(Node** headRef, int newData); // Adds a new node at the head of the list.

int Pop(Node** headRef); // Removes the head node and returns its data.

int Count(Node* head, int searchFor); // Counts occurrences of a given integer in the list.

int GetNth(Node** head, int index); // Returns the data at a specific index.

void DeleteList(Node** head); // Deletes all nodes and frees memory.

void InsertNth(Node** head, int index, int data); // Inserts a node at a given index.

void MoveNode(Node** destRef, Node** sourceRef); // Moves the front node from source to destination list.

void RecursiveReverse(Node** headRef); // Recursively reverses the linked list.

//#endif LINKEDLIST_H
